function navigator(target) {
  window.location.href = target;
}

export default navigator;
